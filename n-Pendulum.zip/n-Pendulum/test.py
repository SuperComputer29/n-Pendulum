from sympy import *

x, y, z, f, d = symbols("x y z f d")

f = 3*x*y/z*d - 2
f = lambdify([x, y, z], f)


print(d[3])

