# Generate a random angle for t1 upto tn and set tp equal to 0 and then put these values
# into the equation for the acceleration and solve it and then use that to solve for the angle at that time

import tensorflow as tf
from matplotlib import pyplot as plot
from random import uniform
from general_solution import inputs, outputs, n, N
from math import sin



N = n # Number of bobs
examples = N # Number of examples in the dataset
n_train = 1500
n_test = examples
x_train, y_train = inputs[:n_train], outputs[:n_train]
x_test, y_test = inputs[1500: 2000], outputs[1500: 2000]
print(len(x_test))
model = tf.keras.models.Sequential()
model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
model.add(tf.keras.layers.Dense(128, activation=tf.nn.relu))
model.add(tf.keras.layers.Dense(N, activation=tf.nn.relu))

model.compile(optimizer='adam',
              loss='mse',
              metrics=['accuracy'])
              

model.fit(x_train, y_train, epochs=100)
print(str(len(x_test)) + "hi")
val_loss, val_acc = model.evaluate(x_test, y_test)

model.save('nPendulum')
nPendulum_model = tf.keras.models.load_model('nPendulum')

predictions = nPendulum_model.predict(x_test)

print(predictions[0])
print(outputs[0])